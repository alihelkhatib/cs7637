class SentenceFrame:
    def __init__(self, subjects: list, verb: str, noun: str = None, noun_adjectives: list = None, recipient: str = None,
                 location: str = None, time: str = None, quantities: str = None):
        self.subjects = subjects
        self.verb = verb
        self.noun = noun
        self.noun_adjectives = noun_adjectives
        self.recipient = recipient
        self.location = location
        self.time = time
        self.quantities = quantities

    def __str__(self):
        return f"subjects words: {self.subjects}, verb: {self.verb}, noun: {self.noun}," \
               f" noun_adjectives: {self.noun_adjectives}, recipent: {self.recipient}," \
               f" location: {self.location}, time: {self.time}, quantities: {self.quantities}"
